package com.example.root.olvoagent.models.ListCategoryShop;

/**
 * Created by root on 12/11/19.
 */

public class ErrorCategory {
}
