package com.example.root.olvoagent.models.ListRegionModel;

/**
 * Created by root on 13/11/19.
 */

public class RegionError {
}
