package com.example.root.olvoagent.models.RouteApiModel;

/**
 * Created by root on 20/9/19.
 */

public class ErrorModel {

}
