package com.example.root.olvoagent.models.ToupUpHistoryModel;

/**
 * Created by root on 21/10/19.
 */

public class ErrorDateModel {
}
