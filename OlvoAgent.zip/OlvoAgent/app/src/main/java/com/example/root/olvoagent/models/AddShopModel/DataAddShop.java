package com.example.root.olvoagent.models.AddShopModel;

/**
 * Created by root on 30/10/19.
 */

public class DataAddShop {

//    @SerializedName("name")
//    private String Shopname;
//
//    @SerializedName("email")
//    private String ShopEmail;
//
//    @SerializedName("country_code")
//    private Integer shopCountryCode;
//
//    @SerializedName("mobile_number")
//    private Integer shopMobile;
//
//    @SerializedName("region")
//    private String shopRegion;
//
//    @SerializedName("shop_status")
//    private Integer shopStatus;
//
//    @SerializedName("enable_voip")
//    private Integer enableVoip;
//
//    @SerializedName("enable_mobile")
//    private Integer enableMobile;
//
//
//    @SerializedName("route_id")
//    private String routeId;
//
//    @SerializedName("threshold")
//    private Integer shopThreshold;
//
//    @SerializedName("shop_category")
//    private String firstShopCategory;
//
//    @SerializedName("shop_category")
//    private String secondShopCategory;
//
//
//    public String getShopname() {
//        return Shopname;
//    }
//
//    public void setShopname(String shopname) {
//        this.Shopname = shopname;
//    }
//
//    public String getShopEmail() {
//        return ShopEmail;
//    }
//
//    public void setShopEmail(String shopEmail) {
//        this.ShopEmail = shopEmail;
//    }
//
//    public Integer getShopCountryCode() {
//        return shopCountryCode;
//    }
//
//    public void setShopCountryCode(Integer shopCountryCode) {
//        this.shopCountryCode = shopCountryCode;
//    }
//
//    public Integer getShopMobile() {
//        return shopMobile;
//    }
//
//    public void setShopMobile(Integer shopMobile1) {
//        this.shopMobile = shopMobile1;
//    }
//
//    public String getShopRegion() {
//        return shopRegion;
//    }
//
//    public void setShopRegion(String shopRegion1) {
//        this.shopRegion = shopRegion1;
//    }
//
//    public Integer getShopStatus() {
//        return shopStatus;
//    }
//
//    public void setShopStatus(Integer shopStatus1) {
//        this.shopStatus = shopStatus1;
//    }
//
//    public Integer getEnableVoip() {
//        return enableVoip;
//    }
//
//    public void setEnableVoip(Integer enableVoip1) {
//        this.enableVoip = enableVoip1;
//    }
//
//    public Integer getEnableMobile() {
//        return enableMobile;
//    }
//
//    public void setEnableMobile(Integer enableMobile1) {
//        this.enableMobile = enableMobile1;
//    }
//
//    public String getRouteId() {
//        return routeId;
//    }
//
//    public void setRouteId(String routeId1) {
//        this.routeId = routeId1;
//    }
//
//    public Integer getShopThreshold() {
//        return shopThreshold;
//    }
//
//    public void setShopThreshold(Integer shopThreshold1) {
//        this.shopThreshold = shopThreshold1;
//    }
//
//    public String getFirstShopCategory() {
//        return firstShopCategory;
//    }
//
//    public void setFirstShopCategory(String firstShopCategory1) {
//        this.firstShopCategory = firstShopCategory1;
//    }
//
//    public String getSecondShopCategory() {
//        return secondShopCategory;
//    }
//
//    public void setSecondShopCategory(String secondShopCategory) {
//        this.secondShopCategory = secondShopCategory;
//    }

}
