package com.example.root.olvoagent.models.DeleteRouteModel;

/**
 * Created by root on 7/11/19.
 */

public class DeleteData {

}
