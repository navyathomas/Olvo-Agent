package com.example.root.olvoagent.models.RouteAddModel;

/**
 * Created by root on 7/11/19.
 */

public class RouteData {


}
