package com.example.root.olvoagent.models.HomeAdModel;

/**
 * Created by root on 29/8/19.
 */

public class ErrorModel {


}
