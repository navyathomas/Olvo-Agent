package com.example.root.olvoagent.models.RechargeHistory;

/**
 * Created by root on 30/9/19.
 */

public class ErrorModel {
}
